package com.volkswagen.internal_stackoverflow;

import org.junit.jupiter.api.Test;
import org.springframework.test.context.ContextConfiguration;

@ContextConfiguration
class InternalStackoverflowApplicationTests {

	@Test
	void contextLoads() {
	}

}
