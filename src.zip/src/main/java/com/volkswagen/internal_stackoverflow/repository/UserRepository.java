package com.volkswagen.internal_stackoverflow.repository;

import com.volkswagen.internal_stackoverflow.entity.User;
import org.springframework.data.jpa.repository.JpaRepository;

public interface UserRepository extends JpaRepository<User, Long> {
    User findByUsername(String username);
    User findByEmail(String email);
}
