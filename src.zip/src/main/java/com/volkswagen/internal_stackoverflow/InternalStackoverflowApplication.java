package com.volkswagen.internal_stackoverflow;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class InternalStackoverflowApplication {

	public static void main(String[] args) {
		SpringApplication.run(InternalStackoverflowApplication.class, args);
	}

}
